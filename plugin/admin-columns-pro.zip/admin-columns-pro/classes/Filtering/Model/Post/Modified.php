<?php

namespace ACP\Filtering\Model\Post;

/**
 * @deprecated 6.4
 */
class Modified extends Date
{

    public function __construct($column)
    {
        parent::__construct($column);
    }

}