<?php

namespace ACP\Filtering\Model\Post;

use ACP\Search;

/**
 * @deprecated 6.4
 */
class Content extends Search\Comparison\Post\Content
{

}