<?php

namespace ACP\Tools\Export;

interface Response
{

    public function send(): void;

}