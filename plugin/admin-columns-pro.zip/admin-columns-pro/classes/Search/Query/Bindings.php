<?php

namespace ACP\Search\Query;

use ACP;

/**
 * deprecated 6.4
 */
class Bindings extends ACP\Query\Bindings
{

}