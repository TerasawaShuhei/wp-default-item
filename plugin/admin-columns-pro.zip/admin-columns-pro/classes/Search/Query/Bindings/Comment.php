<?php

namespace ACP\Search\Query\Bindings;

use ACP;

/**
 * deprecated 6.4
 */
class Comment extends ACP\Query\Bindings\Comment
{

}