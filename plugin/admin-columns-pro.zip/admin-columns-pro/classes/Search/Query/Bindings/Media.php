<?php

namespace ACP\Search\Query\Bindings;

use ACP;

/**
 * deprecated 6.4
 */
class Media extends ACP\Query\Bindings\Media
{

}