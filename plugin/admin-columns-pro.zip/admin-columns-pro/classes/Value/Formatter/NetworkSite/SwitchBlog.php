<?php

namespace ACP\Value\Formatter\NetworkSite;

use AC\Setting\Formatter;
use AC\Type\Value;
use AC\Value\Formatter\Aggregate;

class SwitchBlog implements Formatter
{

    private Aggregate $formatter;

    public function __construct(array $formatters)
    {
        $this->formatter = Aggregate::from_array($formatters);
    }

    public function format(Value $value): Value
    {
        switch_to_blog($value->get_id());

        $value = $this->formatter->format($value);

        restore_current_blog();

        return $value;
    }
}